source pid.pid

kill -SIGTERM $var