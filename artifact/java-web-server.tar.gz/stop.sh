source process.id

kill -SIGTERM $var